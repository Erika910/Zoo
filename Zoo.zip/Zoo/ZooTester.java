import java.util.List;
import java.util.ArrayList;
import java.util.*;
import java.util.concurrent.TimeUnit;
/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ZooTester
{
    public static void main(String[] args) throws InterruptedException
    {
        System.out.println();
        double cash = 50.00;
        double odds;
        int range = 100 - 1 + 1;
        List<Animal> animals = new ArrayList<>();

        System.out.println("Welcome to the Zoo!\n");
        System.out.print("Building the cages");
        delayDots(3);
        System.out.print("Populating the animals");
        populateAnimals(animals);
        delayDots(3);
        System.out.print("Hiring zookeppers");
        delayDots(3);

        Scanner in =  new Scanner(System.in);
        String text = in.nextLine();
        String msg = "";
        while (!text.equals("leave"))
        {
            switch(text)
            {
                case "help":
                msg = "visit cages , look up , look around , look in the water , walk forward, watch the animals eat , listen to the animals , Add Money , My Wallet , ConsessionsStand , Gift Shop , Amusement Park , leave?";
                break;
                case "visit cages":
                msg = visitCages(animals);
                break;
                case "look up":
                msg = lookUp(animals);
                break;
                case "look around":
                msg = lookAround(animals);
                break;
                case "look in the water":
                msg = lookInWater(animals);
                break;
                case "watch the animals eat":
                msg = LunchTime(animals);
                break;
                case "listen to the animals":
                msg = Listen(animals);
                break;
                case "Add Money":
                msg = "How much $5.00, $10.00, $20.00?";
                break;

                case "$5.00":
                msg = "You added $5.00 to your account.";
                cash = cash + 5.00;
                break;

                case "$10.00":
                msg = "You added $10.00 to your account.";
                cash = cash + 10.00;
                break;

                case "$20.00":
                msg = "You added $20.00 to your account.";
                cash = cash + 20.00;
                break;

                case "My Wallet":
                msg = "";
                odds = (int)(Math.random() * range) + 1;
                if(odds <= 25)
                {
                    System.out.println("Your Wallet has been snatched.");
                    cash = 0.0;
                    System.out.println("You now have $" + cash);
                }
                else
                {
                    System.out.println("You have $" + cash);
                }
                break;

                case "ConsessionsStand":
                msg = "What do you want? Hot Dog, Drink, Nachos";
                break;

                case "Hot Dog":
                if(cash >= 2.50)
                {
                    msg = "that'll be $2.50";
                    cash = cash - 2.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Drink":
                if(cash >= 1.50)
                {
                    msg = "that'll be $1.50";
                    cash = cash - 1.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Nachos":
                if(cash >= 3.50)
                {
                    msg = "that'll be $3.50";
                    cash = cash - 3.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Gift Shop":
                msg = "What do you want from the gift shop. Toy, Cup, Wallet, Stuffed Animal?";
                break;

                case "Toy":
                if(cash >= 5.00)
                {
                    msg = "that'll be $5.00";
                    cash = cash - 5.00;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Cup":
                if(cash >= 3.50)
                {
                    msg = "that'll be $3.50";
                    cash = cash - 3.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;
                
                case "Wallet":
                if(cash >= 2.50)
                {
                    msg = "that'll be $2.50";
                    cash = cash - 2.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Stuffed Animal":
                if(cash >= 6.00)
                {
                    msg = "that'll be $6.00";
                    cash = cash - 6.00;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;

                case "Amusement Park":
                msg = "What would you like to do in the amusment park? See the Circus, Ride the Ferris Wheel, Ride the Rollercoster";
                System.out.println("         o");
                System.out.println("       o |");
                System.out.println("       |");
                System.out.println("     .       .           ._._.    _                     .===.");
                System.out.println("     |`      |`        ..'| |`.. |H|        .--.      .:'   `:.");
                System.out.println("    ///-...-/|/         |- o -|  |H|`.     /||||/     ||     ||");
                System.out.println("._.'//////,'|||`._.    '`.|||.'` |\\||:. .'||||||`.   `:.   .:'");
                System.out.println("||||||||||||[ ]||||      |_T_|   |:`:.--'||||||||||`--..`=:='...");
                break;
                
                case "See the Circus":
                msg = "You laughed and had a good time seeing the different acts.";
                System.out.println("         o");
                System.out.println("       o |");
                System.out.println("       |");
                System.out.println("     .       .     ");
                System.out.println("     |`      |`    ");
                System.out.println("    ///-...-/|/    ");
                System.out.println("._.'//////,'|||`._.");
                System.out.println("||||||||||||[ ]||||");
                break;
                
                case "Ride the Ferris Wheel":
                msg = "The view at the top of the wheel was one of the best things you have seen.";
                System.out.println("  ._._.  ");
                System.out.println("..'| |`..");
                System.out.println(" |- o -| ");
                System.out.println("'`.|||.'`");
                System.out.println("  |_T_|  ");
                break;
                
                case "Ride the Rollercoster":
                msg = "Up and Down and up and down. A great and thrilling ride that had you screaming and laughing the whole time.";
                System.out.println(" _                     .===.");
                System.out.println("|H|        .--.      .:'   `:.");
                System.out.println("|H|`.     /||||/     ||     ||");
                System.out.println("|\\||:. .'||||||`.   `:.   .:'");
                System.out.println("|:`:.--'||||||||||`--..`=:='...");
                break;
                
                case "walk forward":
                msg = "you walk into the zoo and see a statue with writing on it.";
                System.out.println("Turn right and so you can 'visit cages' to see the animals.");
                System.out.println("Turn left and visit the 'Gift Shop' to buy stuff.");
                System.out.println("Or turn back around and 'leave'.");
                break;
                
                /*case "Books":
                if(cash >= 15.50)
                {
                    msg = "that'll be $15.50";
                    cash = cash - 15.50;
                    System.out.println("You have $"  + cash + " remaining.");
                }
                else
                {
                    msg = "You can't afford this.";
                }
                break;*/
                
                //case "Read Books":
                //msg = "You find a good book to read so you focus all your attention on the book instead of the animals.";
                //break;
                
                //case "walk into cages":
                //msg = "you walk into the animals cages and are now kicked out of the zoo. Type leave.";
                //break;
            
                default: msg = "You flail helplessly with indesision";
            }
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("What now");
            text = in.nextLine();
        }
    }  

    public static void populateAnimals(List<Animal> animals)
    {
        Fox a1 = new Fox();
        animals.add(a1);

        Bunny a2 = new Bunny();
        animals.add(a2);

        Penguin a3 = new Penguin();
        animals.add(a3);

        Sheep a4 = new Sheep();
        animals.add(a4);

        Bear a5 = new Bear();
        animals.add(a5);

        GoldFish a6 = new GoldFish();
        animals.add(a6);

        Husky a7 = new Husky();
        animals.add(a7);

        Anaconda a8 = new Anaconda();
        animals.add(a8);

        Trex a9 = new Trex();
        animals.add(a9);

        Thwomp a10 = new Thwomp();
        animals.add(a10);

        Platypus a11 = new Platypus();
        animals.add(a11);

        Rhino a12 = new Rhino();
        animals.add(a12);

        Shark a13 = new Shark();
        animals.add(a13);

        Walter a14 = new Walter();
        animals.add(a14);

        Droid a15 = new Droid();
        animals.add(a15);

        Bella a16 = new Bella();
        animals.add(a16);

        Abominablesnowman a17 = new Abominablesnowman();
        animals.add(a17);

        Llama a18 = new Llama();
        animals.add(a18);

        goomba a19 = new goomba();
        animals.add(a19);

        SunBear a20 = new SunBear();
        animals.add(a20);

        FruitBat a21 = new FruitBat();
        animals.add(a21);

        Phish a22 = new Phish();
        animals.add(a22);

        Bokoblin a23 = new Bokoblin();
        animals.add(a23);

        MourningDove a24 = new MourningDove();
        animals.add(a24);

        Vince a25 = new Vince();
        animals.add(a25);

        Duck a26 = new Duck();
        animals.add(a26);

        RedPanda a27 = new RedPanda();
        animals.add(a27);

        Lizalfo a28 = new Lizalfo();
        animals.add(a28);

        LR57CombatDroid a29 = new LR57CombatDroid();
        animals.add(a29);

        FleshMonster a30 = new FleshMonster();
        animals.add(a30);

        IronTarkus a31 = new IronTarkus();
        animals.add(a31);

        Moblin a32 = new Moblin();
        animals.add(a32);

        RedCrowCrane a33 = new RedCrowCrane();
        animals.add(a33);

        HomunculusFleshPuppet a34 = new HomunculusFleshPuppet();
        animals.add(a34);

        Bigfoot a35 = new Bigfoot();
        animals.add(a35);

        JapaneseMacaque a36 = new JapaneseMacaque();
        animals.add(a36);

        JapaneseGiantSalamander a37 = new JapaneseGiantSalamander();
        animals.add(a37);

        Lochnessmonster a38 = new Lochnessmonster();
        animals.add(a38);

    }

    public static String visitCages(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      " + a.getDescription() + "\n"; 
        }
        return msg;
    }

    public static String LunchTime(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      " + a.eat() + "\n"; 
        }
        return msg;
    }

    public static String Listen(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n      " + a.makeNoise() + "\n"; 
        }
        return msg;
    }

    public static String lookUp(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        { 
            if(a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg += a.getName() + ": \n      " + a.getDescription() + "\n" + f.fly() + "\n"; 
            }
        }
        return msg;
    }

    public static String lookAround(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        { 
            if(a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n      " + a.getDescription() + "\n" + w.walk() + "\n"; 
            }
        }
        return msg;
    }

    public static String lookInWater(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        { 
            if(a instanceof Swimming)
            {
                Swimming s = (Swimming)a;
                msg += a.getName() + ": \n      " + a.getDescription() + "\n" + s.swim() + "\n"; 
            }
        }
        return msg;
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for (int i=0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }
}