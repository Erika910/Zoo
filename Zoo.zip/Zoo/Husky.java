
/**
 * Write a description of class Husky here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Husky extends Animal
    implements Walking, Swimming
{
    public Husky()
    {
        // initialise instance variables
        this("Huggy the Husky", "Meow");
    }

    public Husky(String name, String description) {
        super(name, description);
    }
   
    @Override
    public String eat(){
        return "Chews on dog food";
    }
   
    @Override
    public String makeNoise(){
        return "sniff sniff *meow*";
    }
    
    @Override
    public String walk()
    {
        return "Strut";
    }
    
     @Override
    public String swim()
    {
        return "paddle";
    }
}
