
/**
 * Write a description of class Bear here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bear extends Animal
{
    public Bear()
    {
        // initialise instance variables
        this("Black the Bear", "Rar");
    }

    public Bear(String name, String description) {
        super(name, description);
    }
   
    @Override
    public String eat(){
        return "Chews on Seal Fat";
    }
   
    @Override
    public String makeNoise(){
        return "grunt *sniff* *sniff* *sniff* grunt";
    }
}