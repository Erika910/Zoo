
/**
 * Write a description of class Fox here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fox extends Animal
    implements Walking, Swimming
{
    public Fox()
    {
        this("Fred the Fox", "likes to run around");
    }
    
    public Fox(String name, String description)
    {
        super(name, description);
    }
    
    @Override
    
    public String eat()
    {
        return "Chews on fruit";
    }
    
    @Override
    
    public String makeNoise()
    {
        return "bark";
    }
    
    @Override
    
    public String walk()
    {
        return "stealth";
    }
    
    @Override
    
    public String swim()
    {
        return "paddle";
    }
}
