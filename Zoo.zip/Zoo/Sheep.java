
/**
 * Write a description of class Sheep here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sheep extends Animal
    implements Walking, Swimming
{
    public Sheep()
    {
        this("Fluffy the sheep", "likes grass");
    }
    
    public Sheep(String name, String description)
    {
        super(name, description);
    }
    
    @Override
    
    public String eat()
    {
        return "Chews on grass";
    }
    
    @Override
    
    public String makeNoise()
    {
        return "stomp";
    }
    
    @Override
    
    public String walk()
    {
        return "slow";
    }
    
    @Override
    
    public String swim()
    {
        return "heavy";
    }
}
