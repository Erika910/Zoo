
/**
 * Write a description of class Bunny here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bunny extends Animal
    implements Walking, Swimming
{
    public Bunny()
    {
        this("Bounce the bunny", "like jumping around");
    }
    
    public Bunny(String name, String description)
    {
        super(name, description);
    }
    
    @Override
    
    public String eat()
    {
        return "Eats carrots";
    }
    
    @Override
    
    public String makeNoise()
    {
        return "Nibble";
    }
    
    @Override
    
    public String walk()
    {
        return "bounce bounce";
    }
    
    @Override
    
    public String swim()
    {
        return "paddle";
    }
    
}
